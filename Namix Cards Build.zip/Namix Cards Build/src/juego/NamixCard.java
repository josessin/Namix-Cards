/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juego;

import vistas.InicioJuego;

/**
 *
 * @author Jose
 */
public class NamixCard {
    
    public static void main(String[] args){
        InicioJuego in;
        in = new InicioJuego();
                in.setVisible(true);
        
//        Juego juego;
//        //Crear la clase principal responsable de el loop 
//        juego = new Juego();
        
    }
    
}
